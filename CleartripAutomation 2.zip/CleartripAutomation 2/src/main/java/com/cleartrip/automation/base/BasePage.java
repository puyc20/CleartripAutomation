package com.cleartrip.automation.base;

import com.aventstack.extentreports.ExtentTest;
import com.cleartrip.automation.utils.LogUtil;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BasePage {
    protected WebDriver driver;
    protected Logger logger;
    protected ExtentTest test;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver, ExtentTest test) {
        this.driver = driver;
        this.test = test;
        this.logger = LogUtil.getLogger(this.getClass());
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    protected void click(By locator) {
        wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
        logger.info("Clicked element: " + locator);
        test.info("Clicked element: " + locator);

    }
    protected void jsClick(By locator)
    {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        logger.info("Clicked element using JS: " + locator);
        test.info("Clicked element using JS: " + locator);
    }

    protected void type(By locator, String text) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        element.clear();
        element.sendKeys(text);
        logger.info("Typed '" + text + "' in element: " + locator);
        test.info("Typed '" + text + "' in element: " + locator);
    }

    protected String getText(By locator) {
        String text = wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).getText();
        logger.info("Got text from element " + locator + ": " + text);
        test.info("Got text from element " + locator + ": " + text);
        return text;
    }

    protected boolean isElementVisible(By locator) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            logger.info("Element visible: " + locator);
            return true;
        } catch (TimeoutException e) {
            logger.warn("Element not visible: " + locator);
            return false;
        }
    }

    protected void waitForElement(By locator) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        logger.info("Waited for element: " + locator);
    }

    protected void scrollToElement(By locator) {
        WebElement element = driver.findElement(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        logger.info("Scrolled to element: " + locator);
    }
}
