package com.cleartrip.automation.base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.cleartrip.automation.utils.LogUtil;
import com.cleartrip.automation.utils.ScreenshotUtil;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.lang.reflect.Method;
import java.time.Duration;

public class BaseTest {
    protected static WebDriver driver;
    protected static ExtentReports extent;
    protected static ThreadLocal<ExtentTest> test = new ThreadLocal<>();
    protected static Logger logger;

    @BeforeSuite(alwaysRun = true)
    public void setUpSuite() {
        // Initialize ExtentReports
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter("test-output/ExtentReport.html");
        sparkReporter.config().setTheme(Theme.STANDARD);
        sparkReporter.config().setDocumentTitle("Cleartrip Automation Report");
        sparkReporter.config().setReportName("Flight Booking Automation");
        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);

        // Initialize Logger
        logger = LogUtil.getLogger(BaseTest.class);
        logger.info("Test Suite Started");
    }

    @Parameters({"browser"})
    @BeforeMethod(alwaysRun = true)
    public void setUp(@Optional("chrome") String browser, Method method) {
        // Setup WebDriver
        if (browser.equalsIgnoreCase("chrome")) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        }
        // Add other browsers if needed

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Start ExtentTest for this method
        ExtentTest extentTest = extent.createTest(method.getName());
        test.set(extentTest);

        logger.info("Test Started: " + method.getName());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result, Method method) {
        // Capture screenshot on failure or success
        if (result.getStatus() == ITestResult.FAILURE) {
            String screenshotPath = ScreenshotUtil.captureScreenshot(driver, method.getName());
            test.get().fail(result.getThrowable());
            test.get().addScreenCaptureFromPath(screenshotPath);
            logger.error("Test Failed: " + method.getName());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            String screenshotPath = ScreenshotUtil.captureScreenshot(driver, method.getName());
            test.get().pass("Test Passed");
            test.get().addScreenCaptureFromPath(screenshotPath);
            logger.info("Test Passed: " + method.getName());
        } else if (result.getStatus() == ITestResult.SKIP) {
            test.get().skip("Test Skipped");
            logger.warn("Test Skipped: " + method.getName());
        }

        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite(alwaysRun = true)
    public void tearDownSuite() {
        if (extent != null) {
            extent.flush();
        }
        logger.info("Test Suite Finished");
    }

    public static WebDriver getDriver() {
        return driver;
    }

    public static ExtentTest getTest() {
        return test.get();
    }
}
