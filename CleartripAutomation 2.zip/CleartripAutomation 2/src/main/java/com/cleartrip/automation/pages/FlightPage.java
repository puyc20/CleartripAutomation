package com.cleartrip.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class FlightPage {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        try {
            driver.get("https://www.cleartrip.com/flights");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

            WebElement nonStopCheckbox = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath
                            ("//*[@id=\"__next\"]/div/main/div[3]/div/div[1]/div/div[4]/div/div[2]/div/div[1]/div[1]")));
            if (!nonStopCheckbox.isSelected()) {
                nonStopCheckbox.click();
            }


            List<WebElement> bookNowButtons = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                    By.xpath("//*[@id=\"__next\"]/div/main/div[3]/div/div[2]/div[3]/div[1]/div[2]/div[2]/button/div/h4/p"
            )));

            if (!bookNowButtons.isEmpty()) {
                bookNowButtons.get(0).click();
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}