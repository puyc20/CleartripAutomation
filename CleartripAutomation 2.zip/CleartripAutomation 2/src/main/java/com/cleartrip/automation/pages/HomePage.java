package com.cleartrip.automation.pages;

import com.aventstack.extentreports.ExtentTest;
import com.cleartrip.automation.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {


    private By oneWayRadio = By.xpath(".//span[contains(text(),'One way')]");
    private By roundTripRadio = By.xpath(".//p[contains(text(),'Round trip')]");

    private By fromInput = By.xpath(".//input[@placeholder='Where from?']");
    private By toInput = By.xpath(".//input[@placeholder='Where to?']");


    private By doneButton = By.xpath(".//*[@id=\"__next\"]/div/main/div/div/div/div[1]/div[1]/div/div[1]/div[2]/div/div[7]/button/div/h4");
    private By searchButton = By.xpath("//h4[normalize-space(text())='Search flights']");

    public HomePage(WebDriver driver, ExtentTest test) {
        super(driver, test);
    }

    public void openSite() {
        driver.get("https://www.cleartrip.com/flights");
        logger.info("Navigated to Cleartrip Flights page");
        test.info("Navigated to Cleartrip Flights page");
        closeLoginBannerIfPresent();
    }

    private void closeLoginBannerIfPresent() {
        try {
            By closeBtn = By.xpath("//*[@data-testid='loginPopup']//div[@class='pb-1 px-1 flex flex-middle nmx-1']");
            if (isElementVisible(closeBtn)) {
                click(closeBtn);
                logger.info("Closed login/banner overlay");
                test.info("Closed login/banner overlay");
            }
        } catch (Exception e)
        {

        }
    }

    public void selectRoundTrip() {
        if (isElementVisible(oneWayRadio))
        {
            click(oneWayRadio);

        }
        click(roundTripRadio);

    }

    public void setFromCity(String city) {
        click(fromInput);
        type(fromInput, city);

        By suggestion = By.xpath(" //ul//p[contains(text(),'" + city + "')]");

        waitForElement(suggestion);
        click(suggestion);
    }

    public void setToCity(String city) {
        click(toInput);
        type(toInput, city);

        By suggestion = By.xpath("//ul//p[contains(text(),'" + city + "')]");
        waitForElement(suggestion);
        click(suggestion);
    }



    public void clickSearchFlights() {
        click(searchButton);
    }
}
