package com.cleartrip.automation.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CsvUtil {
    private static final String TESTDATA_PATH = "src/test/resources/TestData.csv";

    public static Map<String, String> getRowDataAsMap(int rowNum) {
        Map<String, String> data = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(TESTDATA_PATH))) {
            String headerLine = br.readLine();
            if (headerLine == null) return data;
            String[] headers = headerLine.split(",");
            String line = null;
            int currentRow = 0;
            while ((line = br.readLine()) != null) {
                if (currentRow == rowNum - 1) { // rowNum is 1-based (skip header)
                    String[] values = line.split(",");
                    for (int i = 0; i < headers.length && i < values.length; i++) {
                        data.put(headers[i].trim(), values[i].trim());
                    }
                    break;
                }
                currentRow++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }
}
