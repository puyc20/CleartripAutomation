package com.cleartrip.automation.utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotUtil {
    public static String captureScreenshot(WebDriver driver, String screenshotName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String destDir = "test-output/screenshots";
        String destPath = destDir + "/" + screenshotName + "_" + timestamp + ".png";
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destFile = new File(destPath);
            File dir = new File(destDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            FileUtils.copyFile(srcFile, destFile);
            return destPath;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
