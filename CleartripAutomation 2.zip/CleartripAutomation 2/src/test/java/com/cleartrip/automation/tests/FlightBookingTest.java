package com.cleartrip.automation.tests;

import com.cleartrip.automation.base.BaseTest;
import com.cleartrip.automation.pages.*;
import com.cleartrip.automation.utils.CsvUtil;
import org.testng.annotations.Test;

import java.util.Map;
import java.util.Random;

public class FlightBookingTest extends BaseTest {

    @Test(description = "End-to-end flight booking scenario on Cleartrip", priority = 1)
    public void testFlightBookingE2E() {
        // Fetch test data from CSV
        Map<String, String> data = CsvUtil.getRowDataAsMap(1);

        HomePage home = new HomePage(driver, test.get());


        // Launch Platform
        home.openSite();

        // Input Trip Details
        home.setFromCity(data.getOrDefault("FromCity", "Bangalore"));
        home.setToCity(data.getOrDefault("ToCity", "Kolkata"));
        home.selectRoundTrip();
        home.clickSearchFlights();
//        home.setPassengers(
//                Integer.parseInt(data.getOrDefault("Adults", "1")),
//                Integer.parseInt(data.getOrDefault("Children", "1"))
//        );
    }
}